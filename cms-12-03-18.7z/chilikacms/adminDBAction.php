<?php require_once("includes/app_common.php");
$action = $_REQUEST['act'];
switch($action){
	case "sadminlogin":{		
		$userid = input($_REQUEST['userid']);
		$password = input($_REQUEST['password']);
		$pwd = md5($password);
		$dt = date('d-m-Y');
		$sql = "SELECT * from ".ADMIN." where userid='$userid' and password='$pwd' and status='1'";
		$res = $db->getData($sql);
		//print_r($res);
		if($res['NO_OF_ITEMS']> 0){
		//echo $res['NO_OF_ITEMS'];
			$_SESSION[SES]['admin'] = $res['oDATA'][0];			
			$dt = date("Y-m-d"); 
			setAdMessage("suc","You have successfully logged in");
			redirect('index.php');
		}
		else{
			
			setAdMessage("err","Invalid Login ID and Password!");
			redirect('login.php');
		}	
	}break;
		
	case "adminlogout":{
		unset($_SESSION[SES]['admin']);
		unset($_SESSION[SES]);
		header("location:login.php");
	}break;	
	case "changepass":{
		$uid = (input($_REQUEST['uid']));		
		$oldpass = md5(input($_REQUEST['oldpass']));
		$conpass = md5(input($_REQUEST['conpass']));
		if(trim($conpass)!="" && trim($uid)!=""){	
			$sql="select * from ".ADMIN." WHERE password='$oldpass' and	uid='$uid'";
			$da = $objHome->getData($sql); 
			if($da['NO_OF_ITEMS'] > 0){
				$sql = "UPDATE ".ADMIN." SET password='$conpass' where uid='$uid'";
				$res = $db->update($sql);
				setAdMessage("suc","Password updated successfully");
				redirect('admin.php');
			}
			else
			{	
				setAdMessage("err","Old password did not match");
				redirect('admin.php');
			}
		}	
	}break;
	case "changeuserpass":{
		$uid = (input($_REQUEST['uid']));		
		$conpass = md5(input($_REQUEST['conpass']));
		if(trim($conpass)!="" && trim($uid)!=""){	
				$sql = "UPDATE ".ADMIN." SET password='$conpass' where uid='$uid'";
				$res = $db->update($sql);
				setAdMessage("suc","Password updated successfully");
				redirect('user.php');
			}
	}break;
	
	case "updateAProfile":{
		$uid = input($_REQUEST['uid']);
		$userid = input($_REQUEST['userid']);
		$signature = input($_REQUEST['signature']);
		$emailid = input($_REQUEST['emailid']);
		$sql="UPDATE  ".ADMIN." SET userid='$userid',emailid='$emailid',signature='$signature' where uid='$uid'";
		$res = $db->update($sql);
		setAdMessage("suc","Profile updated successfully");
		redirect('admin.php');
	}break;	
	case "updateStatus":{
		$uid = input($_REQUEST['uid']);
		$status = input($_REQUEST['status']);
		$sql="UPDATE  ".ADMIN." SET status='$status' where uid='$uid'";
		$res = $db->update($sql);
		setAdMessage("suc","User status updated successfully");
		redirect('user.php');
	}break;
	case "delUser":{
		$uid = input($_REQUEST['uid']);
		$sql="DELETE FROM  ".ADMIN."  where uid='$uid'";
		$res = $db->deleterecord($sql);
		setAdMessage("suc","User deleted  successfully");
		redirect('user.php');
	}break;
	case "adduser":{
		$date = date("Y-m-d h:i:s");
		$userid = input($_REQUEST['userid']);
		$password = md5(input($_REQUEST['password']));
		$emailid = input($_REQUEST['emailid']);
		$signature = input($_REQUEST['signature']);
		$admin_type = input($_REQUEST['admin_type']);
		$manage_alumni = (int)input($_REQUEST['manage_alumni']);
		$manage_photo = (int)input($_REQUEST['manage_photo']);
		$manage_blogs = (int)input($_REQUEST['manage_blogs']);
		$photo_gallery = (int)input($_REQUEST['photo_gallery']);
		$notifications = (int)input($_REQUEST['notifications']);
		$news = (int)input($_REQUEST['news']);
		$upcoming_events = (int)input($_REQUEST['upcoming_events']);
		$status = input($_REQUEST['status']);
		$sql="INSERT INTO ".ADMIN."(userid,password,emailid,signature,admin_type,manage_alumni,manage_photo,manage_blogs,photo_gallery,notifications,news,upcoming_events,status)VALUES('$userid','$password','$emailid','$signature',0,'$manage_alumni','$manage_photo','$manage_blogs','$photo_gallery','$notifications','$news','$upcoming_events',1)";
		$res = $db->inserttoDB($sql);
		setAdMessage("suc","User added successfully");
		redirect('user.php');
		
	}break;
	case "updateuser":{
		$date = date("Y-m-d h:i:s");
		$uid = input($_REQUEST['uid']);
		$userid = input($_REQUEST['userid']);
		$password = md5(input($_REQUEST['password']));
		$emailid = input($_REQUEST['emailid']);
		$signature = input($_REQUEST['signature']);
		$admin_type = input($_REQUEST['admin_type']);
		$manage_alumni = (int)input($_REQUEST['manage_alumni']);
		$manage_photo = (int)input($_REQUEST['manage_photo']);
		$manage_blogs = (int)input($_REQUEST['manage_blogs']);
		$photo_gallery = (int)input($_REQUEST['photo_gallery']);
		$notifications = (int)input($_REQUEST['notifications']);
		$news = (int)input($_REQUEST['news']);
		$upcoming_events = (int)input($_REQUEST['upcoming_events']);
		$status = input($_REQUEST['status']);
		$sql="UPDATE  ".ADMIN." SET userid='$userid',emailid='$emailid',signature='$signature',manage_alumni='$manage_alumni',manage_photo='$manage_photo',manage_blogs='$manage_blogs',photo_gallery='$photo_gallery',notifications='$notifications',news='$news',upcoming_events='$upcoming_events' where uid='$uid'";
		$res = $db->update($sql);
		setAdMessage("suc","User updated successfully");
		redirect('user.php');
		
	}break;
	default: 
		header("location:".$_SERVER['HTTP_REFERER']);
	break;
}
?>