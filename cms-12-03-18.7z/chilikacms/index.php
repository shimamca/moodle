<?php
session_start();
require_once("../includes/settings.php");
require_once("../includes/database.php");
require_once("../includes/classes/db.cls.php");
require_once("../includes/classes/sitedata.cls.php");
require_once("includes/functions/common.php");
require_once("../includes/classes/Admin.cls.php");
$db = new SiteData();
$adminObj = new Admin();
loginValidate();
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <title><?=PAGE_TITLE?> :: ADMIN PANEL</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <!-- Bootstrap -->
	<link href="styles/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="styles/admin.css" />
	<script type='text/javascript' src='js/jquery.min.js'></script>
	<script type='text/javascript' src='js/common.js'></script>
	<script src="js/bootstrap.min.js"></script>
  
</head>
<body>

<?php require_once("includes/header.php"); ?>
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
	<?php require_once("includes/column_left.php"); ?>
      
    </div>
    <div class="col-sm-10 text-left"> 
      <h1>Welcome to Admin Panel</h1>
     
		<p style="color:#DBDBDB;font-size:14px;"><a href="http://projects.allindiaonline.in/chilika.com/chilikacms/welogs.php" target="_blank" title="Browse Weblog"><img src="images/web-browser.png" border="0" align="absmiddle"/> Browse Weblog</a></p>
    </div>
    
  </div>
</div>

<?php require_once("includes/footer.php"); ?>

</body>
</html>
