$(document).ready(function() {
	$(".correct, .error").click(function() {
		$(this).hide(500);
	});
});
function fillURL(txtvalue,txtfld) {
	var nstr = "";
	for(var i=0;i<txtvalue.length;i++) {
		var iChars = "!@#$%^&*()+=[]\\\';,/{}|\":<> ?";
		if (iChars.indexOf(txtvalue.charAt(i)) != -1) {
			nstr += '-';
		}
		else if(txtvalue[i]==" ") {	nstr += '-'; }
		else if(txtvalue[i]=="?") {	nstr += ''; }
		else {
			nstr += txtvalue[i];
		}
	}
	while (nstr.indexOf("--")!=-1){
		nstr=nstr.replace("--","-");
	}
	document.getElementById(txtfld).value = nstr.toLowerCase();
}
