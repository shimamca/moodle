function EmailValid(emailfield)	{
	var email = emailfield;	
	if(email=="")	{
		inlineMsg('mailaddr_email','<strong>Error</strong><br />Email is required field.',2);return false;
	}
	len = email.length;
	if((email.charAt(1)=='@')||(email.charAt(1)=='.'))		{
		inlineMsg('mailaddr_email','<strong>Error</strong><br />Invalid Email.',2);return false;
	}
	if((email.charAt(len-2)=='@')||(email.charAt(len-1)=='.'))	{
		inlineMsg('mailaddr_email','<strong>Error</strong><br />Invalid Email.',2);return false;
	}
	count=0;
	dotcount=0;
	for (i=0; i< email.length; i++)	{
		if(email.charAt(i)=='@')
		count++;
		if(email.charAt(i)=='.')
		dotcount++;
	}		
	if((count !=1)||(dotcount <1))	{
		inlineMsg('mailaddr_email','<strong>Error</strong><br />Invalid Email.',2);return false
	}			  
	return true
}
function integersonly(myfield, e) {
	var key;	var keychar;	
	if (window.event)	   key = window.event.keyCode;
	else if (e)	   key = e.which;
	else	   return true;
	keychar = String.fromCharCode(key);		
	if ((key==null) || (key==0) || (key==8) || (key==9) || (key==13) || (key==27) ) {// control keys
	   return true;
	}	
	else if ((("0123456789").indexOf(keychar) > -1)) {// numbers and dot(.)
	   return true;
	}
	else {
	   return false;
	}
}
function numbersonly(myfield, e) {
	var key;	var keychar;	
	if (window.event)	   key = window.event.keyCode;
	else if (e)	   key = e.which;
	else	   return true;
	keychar = String.fromCharCode(key);		
	if ((key==null) || (key==0) || (key==8) || (key==9) || (key==13) || (key==27) ) {// control keys
	   return true;
	}
	else if ((("0123456789.").indexOf(keychar) > -1)) {// numbers and dot(.)
	   return true;
	}
	else {
	   return false;
	}
}
function namesonly(e){
	var key;	var keychar;	
	if (window.event)		key = window.event.keyCode;
	else if (e)		key = e.which;
	else		return true;
	keychar = String.fromCharCode(key);
	keychar = keychar.toLowerCase();		
	if ((key==null) || (key==0) || (key==8) || (key==9) || (key==13) || (key==27) ) {// control keys
		return true;
	}		
	else if ((("abcdefghijklmnopqrstuvwxyz. ").indexOf(keychar) > -1))// alphas and numbers
		return true;
	else
		return false;
}
function numberrangeonly(e){
	var key;	var keychar;	
	if (window.event)		key = window.event.keyCode;
	else if (e)		key = e.which;
	else		return true;
	keychar = String.fromCharCode(key);
	keychar = keychar.toLowerCase();		
	if ((key==null) || (key==0) || (key==8) || (key==9) || (key==13) || (key==27) ) {// control keys
		return true;
	}		
	else if ((("0123456789-/.").indexOf(keychar) > -1))// alphas and numbers
		return true;
	else
		return false;
}
function editadmin_valid(form){ 
	var name = form.name.value;
	var uname = form.uname.value;
	var email = form.email.value;
		if(name == "") {
			inlineMsg('name','<strong>Error</strong><br />You must enter your Name.',2);
			return false;
		}
		if(uname == "") {
			inlineMsg('uname','<strong>Error</strong><br />You must enter your User Name.',2);
			return false;
		}
		if(email == "") {
			inlineMsg('email','<strong>Error</strong><br />You must enter your Email.',2);
			return false;
		}
		
}
function addadmin_valid(form){ 
	var name = form.name.value;
	var uname = form.uname.value;
	var pass = form.pass.value;
	var repass = form.repass.value;
	var email = form.email.value;
		if(name == "") {
			inlineMsg('name','<strong>Error</strong><br />You must enter your Name.',2);
			return false;
		}
		if(uname == "") {
			inlineMsg('uname','<strong>Error</strong><br />You must enter your User Name.',2);
			return false;
		}
		if(pass == "") {
			inlineMsg('pass','<strong>Error</strong><br />You must enter your Password.',2);
			return false;
		}
		if(pass != repass) {
			inlineMsg('repass','<strong>Error</strong><br />Please re-enter your Password.',2);
			return false;
		}
		if(email == "") {
			inlineMsg('email','<strong>Error</strong><br />You must enter your Email.',2);
			return false;
		}
		
}
function validProfile(form){ 
	var admin_user = form.admin_user.value;
	var admin_name = form.admin_name.value;
	var admin_email = form.admin_email.value;
		if(admin_user == "") {
			inlineMsg('admin_user','<strong>Error</strong><br />You must enter your Username.',2);
			return false;
		}
		if(admin_name == "") {
			inlineMsg('admin_name','<strong>Error</strong><br />You must enter your Name.',2);
			return false;
		}
		if(admin_email == "") {
			inlineMsg('admin_email','<strong>Error</strong><br />You must enter your Email.',2);
			return false;
		}
}
function adminPassword(form){ 
	var newpass = form.newpass.value;
	var conpass = form.conpass.value;
		if(newpass == "") {
			inlineMsg('newpass','<strong>Error</strong><br />You must enter your New Password.',2);
			return false;
		}
		if(conpass == "") {
			inlineMsg('conpass','<strong>Error</strong><br />You must enter your Confirm Password.',2);
			return false;
		}
		if(conpass != newpass) {
			inlineMsg('conpass','<strong>Error</strong><br />Please re-enter your New Password.',2);
			return false;
		}
		
}
// START OF MESSAGE SCRIPT //

var MSGTIMER = 20;
var MSGSPEED = 5;
var MSGOFFSET = 3;
var MSGHIDE = 3;

// build out the divs, set attributes and call the fade function //
function inlineMsg(target,string,autohide) {
  var msg;
  var msgcontent;
  if(!document.getElementById('msg')) {
    msg = document.createElement('div');
    msg.id = 'msg';
    msgcontent = document.createElement('div');
    msgcontent.id = 'msgcontent';
    document.body.appendChild(msg);
    msg.appendChild(msgcontent);
    msg.style.filter = 'alpha(opacity=0)';
    msg.style.opacity = 0;
    msg.alpha = 0;
  } else {
    msg = document.getElementById('msg');
    msgcontent = document.getElementById('msgcontent');
  }
  msgcontent.innerHTML = string;
  msg.style.display = 'block';
  var msgheight = msg.offsetHeight;
  var targetdiv = document.getElementById(target);
  targetdiv.focus();
  var targetheight = targetdiv.offsetHeight;
  var targetwidth = targetdiv.offsetWidth;
  var topposition = topPosition(targetdiv) - ((msgheight - targetheight) / 2);
  var leftposition = leftPosition(targetdiv) + targetwidth + MSGOFFSET;
  msg.style.top = topposition + 'px';
  msg.style.left = leftposition + 'px';
  clearInterval(msg.timer);
  msg.timer = setInterval("fadeMsg(1)", MSGTIMER);
  if(!autohide) {
    autohide = MSGHIDE;  
  }
  window.setTimeout("hideMsg()", (autohide * 2000));
}

// hide the form alert //
function hideMsg(msg) {
  var msg = document.getElementById('msg');
  if(!msg.timer) {
    msg.timer = setInterval("fadeMsg(0)", MSGTIMER);
  }
}

// face the message box //
function fadeMsg(flag) {
  if(flag == null) {
    flag = 1;
  }
  var msg = document.getElementById('msg');
  var value;
  if(flag == 1) {
    value = msg.alpha + MSGSPEED;
  } else {
    value = msg.alpha - MSGSPEED;
  }
  msg.alpha = value;
  msg.style.opacity = (value / 100);
  msg.style.filter = 'alpha(opacity=' + value + ')';
  if(value >= 99) {
    clearInterval(msg.timer);
    msg.timer = null;
  } else if(value <= 1) {
    msg.style.display = "none";
    clearInterval(msg.timer);
  }
}

// calculate the position of the element in relation to the left of the browser //
function leftPosition(target) {
  var left = 0;
  if(target.offsetParent) {
    while(1) {
      left += target.offsetLeft;
      if(!target.offsetParent) {
        break;
      }
      target = target.offsetParent;
    }
  } else if(target.x) {
    left += target.x;
  }
  return left;
}

// calculate the position of the element in relation to the top of the browser window //
function topPosition(target) {
  var top = 0;
  if(target.offsetParent) {
    while(1) {
      top += target.offsetTop;
      if(!target.offsetParent) {
        break;
      }
      target = target.offsetParent;
    }
  } else if(target.y) {
    top += target.y;
  }
  return top;
}

// preload the arrow //
if(document.images) {
  arrow = new Image(7,80); 
  arrow.src = "images/msg_arrow.gif"; 
}