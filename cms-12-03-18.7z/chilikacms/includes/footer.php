<footer class="container-fluid text-center">
  <p>&copy <?=PAGE_TITLE?>, All Rights Reserved&nbsp; &nbsp;</p>
</footer>