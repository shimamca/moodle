<?php
session_start();
require_once("../includes/settings.php");
require_once("../includes/database.php");
require_once("../includes/classes/db.cls.php");
require_once("../includes/classes/sitedata.cls.php");
require_once("includes/functions/common.php");
require_once("../includes/classes/Admin.cls.php");
$db = new SiteData();
$adminObj = new Admin();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?=PAGE_TITLE?> :: ADMIN PANEL</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles/admin.css" />
 <!-- Bootstrap -->
<link href="styles/bootstrap.min.css" rel="stylesheet">
<script type='text/javascript' src='<?=ADMIN_HOME?>js/jquery.min.js'></script>
<script type='text/javascript' src='<?=ADMIN_HOME?>js/common.js'></script>
<style>
.login_form, .registration_form {
    position: absolute;
    top: 0;
    width: 100%;
}
.login_content {
    margin: 0 auto;
    padding: 25px 0 0;
    position: relative;
    text-align: center;
    text-shadow: 0 1px 0 #fff;
    min-width: 280px
}
.login_content a,
.login_content .btn-default:hover {
    text-decoration: none
}
.login_content a:hover {
    text-decoration: underline
}
.login_content h1 {
    font: normal 25px Helvetica, Arial, sans-serif;
    letter-spacing: -0.05em;
    line-height: 20px;
    margin: 10px 0 30px
}
.login_content h1:before,
.login_content h1:after {
    content: "";
    height: 1px;
    position: absolute;
    top: 10px;
    width: 27%
}
.login_content h1:after {
    background: #7e7e7e;
    background: linear-gradient(left, #7e7e7e 0%, #fff 100%);
    right: 0
}
.login_content h1:before {
    background: #7e7e7e;
    background: linear-gradient(right, #7e7e7e 0%, #fff 100%);
    left: 0
}
.login_content h1:before,
.login_content h1:after {
    content: "";
    height: 1px;
    position: absolute;
    top: 10px;
    width: 20%
}
.login_content h1:after {
    background: #7e7e7e;
    background: linear-gradient(left, #7e7e7e 0%, #fff 100%);
    right: 0
}
.login_content h1:before {
    background: #7e7e7e;
    background: linear-gradient(right, #7e7e7e 0%, #fff 100%);
    left: 0
}
.login_content form {
    margin: 20px 0;
    position: relative
}
.login_content form input[type="text"],
.login_content form input[type="email"],
.login_content form input[type="password"] {
    border-radius: 3px;
    -ms-box-shadow: 0 1px 0 #fff, 0 -2px 5px rgba(0, 0, 0, 0.08) inset;
    -o-box-shadow: 0 1px 0 #fff, 0 -2px 5px rgba(0, 0, 0, 0.08) inset;
    box-shadow: 0 1px 0 #fff, 0 -2px 5px rgba(0, 0, 0, 0.08) inset;
    border: 1px solid #c8c8c8;
    color: #777;
    margin: 0 0 20px;
    width: 100%
}
.login_content form input[type="text"]:focus,
.login_content form input[type="email"]:focus,
.login_content form input[type="password"]:focus {
    -ms-box-shadow: 0 0 2px #ed1c24 inset;
    -o-box-shadow: 0 0 2px #ed1c24 inset;
    box-shadow: 0 0 2px #A97AAD inset;
    background-color: #fff;
    border: 1px solid #A878AF;
    outline: none
}
#username {
    background-position: 10px 10px !important
}
#password {
    background-position: 10px -53px !important
}
.login_content form div a {
    font-size: 12px;
    margin: 10px 15px 0 0
}
.reset_pass {
    margin-top: 10px !important
}
.login_content div .reset_pass {
    margin-top: 13px !important;
    margin-right: 39px;
    float: right
}
</style>

</head>
<body onLoad="document.frm.uname.focus();">
<?php getMessage();?>
<div class="login_form">
<div class="col-md-4">&nbsp; </div>
<div class="col-md-4" align="center">
	<section class="login_content">
    	<form name="frm" action="LoginAction.php" method="post">
<input type="hidden" name="act" value="login"><div style="height:50px;">&nbsp;</div>

<div class="login_form">
		
		<h1>Administrator Login</h1>		
		
			<div class="label">Username</div>
			<div><input name="uname" type="text" class="form-control" placeholder="Username" required="" /></div>
			<div class="label">Password</div>
			<div><input name="pass" type="password" class="form-control" placeholder="Password" required="" /></div>
			<div>&nbsp;</div>
			<div align="right"><input type="submit" name="submit" value="Login" class="btn btn-default submit" /> &nbsp;</div>
			<div class="clearfix">&nbsp;</div>
			<div>&copy <?=PAGE_TITLE?>, All Rights Reserved &nbsp; &nbsp;</div>
		
	
</div>

</form>

</section>

    </div>
<div class="col-md-4">&nbsp; </div>
 </div>

</body>
</html>