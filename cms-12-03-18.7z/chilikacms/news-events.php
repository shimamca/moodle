<?php
session_start();
require_once("../includes/settings.php");
require_once("../includes/database.php");
require_once("../includes/classes/db.cls.php");
require_once("../includes/classes/sitedata.cls.php");
require_once("includes/functions/common.php");
require_once("../includes/classes/News.cls.php");
loginValidate();
$db = new SiteData();
$newsObj = new News();
$_curpage = currentPage();
$_SESSION[SES]['curpage'] = currentURL();
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <title><?=PAGE_TITLE?> :: ADMIN PANEL</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <!-- Bootstrap -->
	<link href="styles/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="styles/admin.css" />
	<link rel="stylesheet" type="text/css" href="styles/jdpicker.css" />
	<script type='text/javascript' src='js/jquery.min.js'></script>
	<script type='text/javascript' src='js/common.js'></script>
	<script type='text/javascript' src='js/jquery.jdpicker.js'></script>
	<script type='text/javascript' src='js/validation.js'></script>
	<script type="text/javascript">
	function sortdata(orderby) {
	document.location.href="NewsEventsSort.php?orderby="+orderby;
	} 
	</script>
	<script type='text/javascript' src='js/datetimepicker_css.js'></script>
	<script src="js/bootstrap.min.js"></script>
  
</head>
<body>

<?php require_once("includes/header.php"); ?>
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
	<?php require_once("includes/column_left.php"); ?>
      
    </div>
    <div class="col-sm-10 text-left"> 
      <?php
		$q= isset($_GET['q'])?$_GET['q']:"";
		switch($q) {
			case "add" : {include_once("includes/news_events_add.php"); break;}
			case "edit" : {include_once("includes/news_events_edit.php"); break;}
			default:  {include_once("includes/news_events_list.php"); break;}
		}?>
    </div>
    
  </div>
</div>

<?php require_once("includes/footer.php"); ?>

</body>
</html>
