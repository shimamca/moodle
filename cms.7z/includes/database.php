<?php
//database.php
define("ADMIN", "site_controller");
define("PHOTO_CATEGORYS", "tbl_photo_category");
define("PHOTO_GALLERYS", "tbl_photo_gallery");
define("BANNER", "tbl_banner");
define("TENDERS", "tbl_tenders");
define("NEWS_EVENTS", "tbl_news");
define("PAGES", "tbl_pages");
define("PAGE_CONTENTS", "tbl_page_contents");
define("QUICKLINK", "tbl_quicklink");
define("VIDEOS", "tbl_videos");
define("VISIT_CHILIKA", "tbl_visit_chilika");
define("PUBLICATION", "tbl_publication");
define("AWARDS", "tbl_awards");
define("IMAGES", "tbl_images");
define("ADVERTISEMENT", "tbl_advertisement");

define("HOME_CATEGORYS", "tbl_home_category");
define("HOME_GALLERYS", "tbl_home_gallery");

define("INSTRUMENTS", "tbl_instruments");
?>