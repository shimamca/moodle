<?php
//welogs.php
session_start();
require_once("../includes/settings.php");
require_once("../includes/database.php");
require_once("../includes/classes/db.cls.php");
require_once("../includes/classes/sitedata.cls.php");
require_once("includes/functions/common.php");
require_once("../includes/classes/Admin.cls.php");
$db = new SiteData();
$adminObj = new Admin();
loginValidate();

$searchurl = "";
if(isset($_POST['searchurl'])) {
	$searchurl = addslashes($_POST['searchurl']);
	$_SESSION[SES]['searchurl'] = $searchurl;
}
$searchip = "";
if(isset($_POST['searchip'])) {
	$searchip = addslashes($_POST['searchip']);
	$_SESSION[SES]['searchip'] = $searchip;
}
if(isset($_POST['clear']) && $_POST['clear']=="clearres") {
	unset($_SESSION[SES]['search']);
	if(isset($_SESSION[SES]['searchurl']))	unset($_SESSION[SES]['searchurl']);
	if(isset($_SESSION[SES]['searchip']))	unset($_SESSION[SES]['searchip']);
}

$adjacents = 2;
$query_1 = "";
if($searchurl != "") {
	$query_1 =" where browse_url like '%$searchurl%'";
}
if($searchip != "") {
	$query_1 =" where ip like '%$searchip%'";
}

$query = "SELECT count(*) as total_pages from website_logs";
$query .= $query_1;
$res = $db->getData($query);
$total_pages = $res['oDATA'][0]['total_pages'];
$targetpage = $_SERVER['PHP_SELF']; 	//your file name  (the name of this file)
$limit = 100; 								//how many items to show per page
$page = (int)$_GET['page'];
if($page) $start = ($page - 1) * $limit; 			//first item to display on this page
else $start = 0;								//if no page var is given, set start to 0

$sql1 = "SELECT * from website_logs ".$query_1." order by sn desc LIMIT $start, $limit";
$res = $db->getData($sql1);

if ($page == 0) $page = 1;					//if no page var is given, default to 1.
$prev = $page - 1;							//previous page is page - 1
$next = $page + 1;							//next page is page + 1
$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
$lpm1 = $lastpage - 1;//last page minus 1
$pagination = "";
if($lastpage > 1) {	
	$pagination .= "<div class=\"pagination\">";
	//previous button
	if ($page > 1) 
		$pagination.= "<a href=\"$targetpage?page=$prev\"> &laquo; Previous</a>";
	else
		$pagination.= "<span class=\"disabled\"> &laquo; Previous</span>";	
	
	//pages	
	if ($lastpage <= 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
	{	
		for ($counter = 1; $counter < $lastpage; $counter++)
		{
			if ($counter == $page)
				$pagination.= "<span class=\"current\">$counter</span>";
			else
				$pagination.= "<a href=\"$targetpage?page=$counter\">$counter</a>";					
		}
	}
	elseif($lastpage >= 5 + ($adjacents * 2))	//enough pages to hide some
	{
		//close to beginning; only hide later pages
		if($page < 1 + ($adjacents * 2))		
		{
			for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
			{
				if ($counter == $page)
					$pagination.= "<span class=\"current\">$counter</span>";
				else
					$pagination.= "<a href=\"$targetpage?page=$counter\">$counter</a>";					
			}
			$pagination.= "...";
			$pagination.= "<a href=\"$targetpage?page=$lpm1\">$lpm1</a>";
			$pagination.= "<a href=\"$targetpage?page=$lastpage\">$lastpage</a>";		
		}
		//in middle; hide some front and some back
		elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
		{
			$pagination.= "<a href=\"$targetpage?page=1\">1</a>";
			$pagination.= "<a href=\"$targetpage?page=2\">2</a>";
			$pagination.= "...";
			for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<span class=\"current\">$counter</span>";
				else
					$pagination.= "<a href=\"$targetpage?page=$counter\">$counter</a>";					
			}
			$pagination.= "...";
			$pagination.= "<a href=\"$targetpage?page=$lpm1\">$lpm1</a>";
			$pagination.= "<a href=\"$targetpage?page=$lastpage\">$lastpage</a>";		
		}
		//close to end; only hide early pages
		else
		{
			$pagination.= "<a href=\"$targetpage?page=1\">1</a>";
			$pagination.= "<a href=\"$targetpage?page=2\">2</a>";
			$pagination.= "...";
			for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<span class=\"current\">$counter</span>";
				else
					$pagination.= "<a href=\"$targetpage?page=$counter\">$counter</a>";					
			}
		}
	}	
	if ($page < $lpm1) 
		$pagination.= "<a href=\"$targetpage?page=$next\">Next &raquo;</a>";
	else
		$pagination.= "<span class=\"disabled\">Next &raquo;</span>";
	$pagination.= "</div><div>&nbsp;</div>\n";		
}
?>
<html>
<head>
<meta http-equiv="refresh" content="300" />
<title>Web Logs</title>
<link rel="stylesheet" type="text/css" href="styles/admin.css" />
<script type='text/javascript' src='js/jquery.min.js'></script>
<script type='text/javascript' src='js/common.js'></script>
<style type="text/css">
.uag {display:none;color:#990000;}
a.link:link {color:#FF3000;}
a.link:visited {color:#000033;}
.ref {display:none;}
.ref a{color:#660099;}
.pagination a {padding:5px;color:#0033FF;font-size:11px;border: solid 1px #CCCCCC;}
.current{padding:5px;color:#0033FF;font-size:11px;border: solid 1px #111111;background: #CCCCCC;}
strong{ color:#000}
.clear_search {background:#CC99FF;padding:2px 8px;}
.search {background:#009999;padding:2px 8px;}
td {font-size: 12px;}
th {font-size: 11px; font-weight: normal; background: #66CCFF;}
</style>
<script type="text/javascript">
$(document).ready(function() {
$('.show_uag').click(function(){$(this).children("div").toggle();});

$(".datagrid tr:even").css('background-color', '#F1F8F5').mouseover(function(){$(this).css('background-color', '#fcfca2');}).mouseout(function(){$(this).css('background-color', '#F1F8F5');});
	$(".datagrid tr:odd").css('background-color', '#FFFFFF').mouseover(function(){$(this).css('background-color', '#fcfca2');}).mouseout(function(){$(this).css('background-color', '#FFFFFF');});
	$(".no tr:even").css('background-color', '#FFFFFF').mouseover(function(){$(this).css('background-color', '#FFFFFF');}).mouseout(function(){$(this).css('background-color', '#FFFFFF');});	
	$(".no tr:odd").css('background-color', '#FFFFFF').mouseover(function(){$(this).css('background-color', '#FFFFFF');}).mouseout(function(){$(this).css('background-color', '#FFFFFF');});
	
});
/**/
</script>
</head>
<body>
<div class="bodydiv">
<?php require_once("includes/header.php"); ?>
<div style="padding: 8px 5px 0px 5px;background:#F4B800;">
	<div class="fleft"><b>Website Logs</b></div>
	<div class="fright"><?=$pagination?></div>
	<div class="clear"></div>
</div>

<div style="padding: 5px 5px 0px 5px;background:#74707E;">
  <div class="fleft">
  <form action="<?=$_SERVER['PHP_SELF']?>" method="POST">
    <input type="text" name="searchurl" size="30" placeholder="Serch by URL" value="<?=$_SESSION[SES]['searchurl']?>"/>
    <input type="submit" value="Search" class="search" />
  </form>
  </div>
  <div class="fleft" style="margin:0 20px;">
  <form action="<?=$_SERVER['PHP_SELF']?>" method="POST">
    <input type="text" name="searchip" size="30" placeholder="Serch by IP" value="<?=$_SESSION[SES]['searchip']?>" />
    <input type="submit" value="Search" class="search"/>
  </form>
  </div>
  <div class="fleft">
  <form action="<?=$_SERVER['PHP_SELF']?>" method="POST">
    <input type="hidden" name="clear" value="clearres" />
    <input type="submit" value="Clear Search" class="clear_search"/>
  </form>
  </div>
  <div class="clear"></div>
</div>  

<?php
if($res['NO_OF_ITEMS']>0) {
?>
<table width="100%" border="1" cellspacing="0" cellpadding="3" bordercolor="#999" align="center" bgcolor="#F2F4F6" class="datagrid">
  <tr>
    <th width="30"><strong>SN</strong></th>
    <th width="40"><strong>ID</strong></th>
    <th width="90"><strong>IP</strong></th>
    <th width="160"><strong>TIME</strong> <small>(DD-MM-YY HH:MM)</small></th>
    <th><strong>URL</strong></th>
    <th width="50"><strong>LINK</strong></th>
  </tr>
  <?php
$i = 1+$start;
foreach ($res['oDATA'] as $data) {
	extract($data);
	//$currentDateTime = $browse_time;
	//$newDateTime = date('d-m-Y h:i A', strtotime($currentDateTime));
	
	//print_r($newDateTime);
	echo '<tr><td>'.$i.'</td><td>'.$sn.'</td><td>'.$ip.'</td><td>'.$browse_time.'</td>'.
	'<td class="show_uag">'.$browse_url.'<div class="ref">&bull; <a href="'.$referer.'" target="_blank">'.$referer.'</a></div><div class="uag">&bull; '.$user_agent.'</div></td><td><a href="http://projects.allindiaonline.in/'.$browse_url.'" target="_blank" class="link">'.Click.'</td></tr>';
	$i++;
}
?>
</table>
<div align="center" style="margin-top:8px;">
  <?=$pagination?>
</div>
<?php } ?>
</div>
</body>
</html>
