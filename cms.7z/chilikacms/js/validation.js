function EmailValid(emailfield)	{
	var email = emailfield;
	
	if(email=="")	{
		document.getElementById('validation_div').innerHTML='Enter Email ID!';
		return false;
	}
	len = email.length;
	if((email.charAt(1)=='@')||(email.charAt(1)=='.'))		{
		//alert("Invalid Email Please try again!");
		document.getElementById('validation_div').innerHTML='Invalid Email Please try again!';
		return false;
	}
	if((email.charAt(len-2)=='@')||(email.charAt(len-1)=='.'))	{
		//alert("Invalid Email Please try again!");
		document.getElementById('validation_div').innerHTML='Invalid Email Please try again!';
		return false;
	}
	count=0;
	dotcount=0;
	for (i=0; i< email.length; i++)	{
		if(email.charAt(i)=='@')
		count++;
		if(email.charAt(i)=='.')
		dotcount++;
	}		
	if((count !=1)||(dotcount <1))	{
		//alert("Invalid Email Please try again!")
		document.getElementById('validation_div').innerHTML='Invalid Email Please try again!';
		return false
	}			  
	return true
}
// JavaScript Document
function setPageContentType(elm) {
	var pagetype =  elm.options[elm.selectedIndex].value;
	var container = '';
	if(pagetype=="static") {
		$("#container_txtarea").hide();
		$("#container_htmlarea").show();
	}
	else {
		$("#container_htmlarea").hide();
		$("#container_txtarea").show();
	}	
}
function page_valid(pageform){ 
	document.getElementById('validation_div').innerHTML='';
	if(pageform.page_name.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter page name!';
		pageform.page_name.focus();
		pageform.page_name.style.borderColor='red';
		return false;
	}else{
		pageform.page_name.style.borderColor='';
	}
	if(pageform.page_url.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter page file name!';
		pageform.page_url.focus();
		pageform.page_url.style.borderColor='red';
		return false;
	}else{
		pageform.page_url.style.borderColor='';
	}
	if(pageform.page_title.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter page title!';
		pageform.page_title.focus();
		pageform.page_title.style.borderColor='red';
		return false;
	}else{
		pageform.page_title.style.borderColor='';
	}			
}
//////////////////////////TENDER////////////////////////
function tender_valid(){
	var frm=document.frm;
	document.getElementById('validation_div').innerHTML='';
	if(frm.title.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter Title!';
		frm.title.focus();
		frm.title.style.borderColor='red';
		return false;
	}else{
		frm.title.style.borderColor='';
	}
	
	if(frm.publish_date.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter Publish Date!';
		frm.publish_date.focus();
		frm.publish_date.style.borderColor='red';
		return false;
	}else{
		frm.publish_date.style.borderColor='';
	}
	
	if(frm.expiry_date.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter Expire Date!';
		frm.expiry_date.focus();
		frm.expiry_date.style.borderColor='red';
		return false;
	}else{
		frm.expiry_date.style.borderColor='';
	}	
}

/////////////////////// News ////////////////////////////////////////
function news_valid(frm){
	var btn=$("input:radio:checked").val();
	//alert(btn);
	document.getElementById('validation_div').innerHTML='';
	if(frm.title.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter title!';
		frm.title.focus();
		frm.title.style.borderColor='red';
		return false;
	}else{
		frm.title.style.borderColor='';
	}
	
	if(frm.publish_date.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter  Publish Date!';
		frm.publish_date.focus();
		frm.publish_date.style.borderColor='red';
		return false;
	}else{
		frm.publish_date.style.borderColor='';
	}
	
}
/////////////////////// Photo ////////////////////////////////////////
function photo_valid(){
	document.getElementById('validation_div').innerHTML='';
	var photo_caption = document.getElementsByName('photo_caption[]');
	var photo_file = document.getElementsByName('photo_file[]');
	for (var i=0; i<photo_caption.length; i++) {         
		if (photo_caption[i].value==""){
			var elmid=photo_caption[i].getAttribute('id');
			document.getElementById('validation_div').innerHTML='Please Enter Title!';
			photo_caption[i].focus();
			return false;      
		}
		if (photo_file[i].value==""){
			var elmid=photo_file[i].getAttribute('id');
			document.getElementById('validation_div').innerHTML='Please Upload Photo!'; 
			photo_file[i].focus();
			
			return false; 
		}
		
	}
}
function photo_editvalid(frm){
	document.getElementById('validation_div').innerHTML='';
	if(frm.photo_caption.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter Caption!';
		frm.photo_caption.focus();
		frm.photo_caption.style.borderColor='red';
		return false;
	}else{
		frm.photo_caption.style.borderColor='';
	}
	
}
/////////////////////// Photo Catagory////////////////////////////////////////
function validateCategory(frm){
	document.getElementById('validation_div').innerHTML='';
	if(frm.category_name.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter Name!';
		frm.category_name.focus();
		frm.category_name.style.borderColor='red';
		return false;
	}else{
		frm.category_name.style.borderColor='';
	}
	
	if(frm.category_url.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter URL!';
		frm.category_url.focus();
		frm.category_url.style.borderColor='red';
		return false;
	}else{
		frm.category_url.style.borderColor='';
	}
	
}
/////////////////////// Quick Link////////////////////////////////////////
function quicklink_valid(frm){
	document.getElementById('validation_div').innerHTML='';
	if(frm.quicklink_name.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter Name!';
		frm.quicklink_name.focus();
		frm.quicklink_name.style.borderColor='red';
		return false;
	}else{
		frm.quicklink_name.style.borderColor='';
	}
	
	
	
}


function add_photo_valid(frm){
	document.getElementById('validation_div').innerHTML='';
	if(frm.photo_caption.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter Caption!';
		frm.photo_caption.focus();
		frm.photo_caption.style.borderColor='red';
		return false;
	}else{
		frm.photo_caption.style.borderColor='';
	}
	
	if(frm.photo_file.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter File!';
		frm.photo_file.focus();
		frm.photo_file.style.borderColor='red';
		return false;
	}else{
		frm.photo_file.style.borderColor='';
	}
	
}
function edit_photo_valid(frm){
	document.getElementById('validation_div').innerHTML='';
	if(frm.photo_caption.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter Caption!';
		frm.photo_caption.focus();
		frm.photo_caption.style.borderColor='red';
		return false;
	}else{
		frm.photo_caption.style.borderColor='';
	}
	
	
	
}
//////////////////////////VIDEOS MANAGEMENT////////////////////////
function video_valid(frm){
	document.getElementById('validation_div').innerHTML='';
	if(frm.title.value.length==0){
		document.getElementById('validation_div').innerHTML='Please Enter Title!';
		frm.title.focus();
		frm.title.style.borderColor='red';
		return false;
	}else{
		frm.title.style.borderColor='';
	}
	
	
	
}