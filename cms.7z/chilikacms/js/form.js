// JavaScript Document
function addPhotoGalleryRow(tableID) {
	var table = document.getElementById(tableID);
	var rowCount = table.rows.length;
	if(rowCount>10) {
		alert ("A maximum of 10 Files can be uploaded at once.");
		return true;
	}
	else {
		var row = table.insertRow(rowCount);
		var cell = Array(); var element = Array(); var i=0;	
		cell[i] = row.insertCell(i);cell[i].innerHTML = rowCount;i++;	
		cell[i] = row.insertCell(i);element[i] = document.createElement("input");
		element[i].type = "text";element[i].name = "photo_caption[]";element[i].setAttribute("id", "photo_caption["+rowCount+"]");
		element[i].setAttribute("size", "70");
		cell[i].appendChild(element[i]);i++;	
		cell[i] = row.insertCell(i);element[i] = document.createElement("input");
		element[i].type = "file";element[i].name = "photo_file[]";element[i].setAttribute("id", "photo_file["+rowCount+"]");
		cell[i].appendChild(element[i]);
		return true;
	}
	
}
function addProjectRow(tableID) {
	//alert(tableID);
	var table = document.getElementById(tableID);
	var rowCount = table.rows.length;
	if(rowCount>10) {
		alert ("A maximum of 10 Data can be uploaded at once.");
		return true;
	}
	else {
		var row = table.insertRow(rowCount);
		var cell = Array(); var element = Array(); var i=0;	
		cell[i] = row.insertCell(i);cell[i].innerHTML = rowCount;i++;
		
		cell[i] = row.insertCell(i);element[i] = document.createElement("textarea");
		element[i].type = "textarea";element[i].name = "project_name[]";element[i].setAttribute("id", "project_name["+rowCount+"]");
		element[i].setAttribute("cols", "20");
		element[i].setAttribute("rows", "10");
		cell[i].appendChild(element[i]);i++;
		
		
		cell[i] = row.insertCell(i);element[i] = document.createElement("input");
		element[i].type = "text";element[i].name = "period[]";element[i].setAttribute("id", "period["+rowCount+"]");
		element[i].setAttribute("size", "10");
		cell[i].appendChild(element[i]);i++;
		
		
		cell[i] = row.insertCell(i);element[i] = document.createElement("textarea");
		element[i].type = "textarea";element[i].name = "investigator[]";element[i].setAttribute("id", "investigator["+rowCount+"]");
		element[i].setAttribute("cols", "20");
		element[i].setAttribute("rows", "10");
		cell[i].appendChild(element[i]);i++;
		
		cell[i] = row.insertCell(i);element[i] = document.createElement("textarea");
		element[i].type = "textarea";element[i].name = "funding_agency[]";element[i].setAttribute("id", "funding_agency["+rowCount+"]");
		element[i].setAttribute("cols", "20");
		element[i].setAttribute("rows", "10");
		cell[i].appendChild(element[i]);i++;
		
		cell[i] = row.insertCell(i);element[i] = document.createElement("input");
		element[i].type = "text";element[i].name = "amount[]";element[i].setAttribute("id", "amount["+rowCount+"]");
		element[i].setAttribute("size", "10");
		cell[i].appendChild(element[i]);
		return true;
	}
	
}

function addPaperRow(tableID) {
	//alert(tableID);
	var table = document.getElementById(tableID);
	var rowCount = table.rows.length;
	if(rowCount>10) {
		alert ("A maximum of 10 Data can be uploaded at once.");
		return true;
	}
	else {
		var row = table.insertRow(rowCount);
		var cell = Array(); var element = Array(); var i=0;	
		cell[i] = row.insertCell(i);cell[i].innerHTML = rowCount;i++;
		
		cell[i] = row.insertCell(i);element[i] = document.createElement("textarea");
		element[i].type = "textarea";element[i].name = "authors[]";element[i].setAttribute("id", "authors["+rowCount+"]");
		element[i].setAttribute("cols", "20");
		element[i].setAttribute("rows", "10");
		cell[i].appendChild(element[i]);i++;
		
		cell[i] = row.insertCell(i);element[i] = document.createElement("textarea");
		element[i].type = "textarea";element[i].name = "paper_title[]";element[i].setAttribute("id", "paper_title["+rowCount+"]");
		element[i].setAttribute("cols", "20");
		element[i].setAttribute("rows", "10");
		cell[i].appendChild(element[i]);i++;
		
		
		
		cell[i] = row.insertCell(i);element[i] = document.createElement("textarea");
		element[i].type = "textarea";element[i].name = "journal[]";element[i].setAttribute("id", "journal["+rowCount+"]");
		element[i].setAttribute("cols", "20");
		element[i].setAttribute("rows", "10");
		cell[i].appendChild(element[i]);i++;
		
		cell[i] = row.insertCell(i);element[i] = document.createElement("input");
		element[i].type = "text";element[i].name = "publication_year[]";element[i].setAttribute("id", "publication_year["+rowCount+"]");
		element[i].setAttribute("size", "10");
		cell[i].appendChild(element[i]);
		return true;
	}
	
}
function deletehotoGalleryRow(tableID) {try {var table = document.getElementById(tableID);var rowCount = table.rows.length;
	if(rowCount>2) {table.deleteRow(rowCount-1);}}catch(e) {;}}
	
	
function deleteProjectRow(tableID) {try {var table = document.getElementById(tableID);var rowCount = table.rows.length;
	if(rowCount>2) {table.deleteRow(rowCount-1);}}catch(e) {;}}	
	
function deletePaperRow(tableID) {try {var table = document.getElementById(tableID);var rowCount = table.rows.length;
	if(rowCount>2) {table.deleteRow(rowCount-1);}}catch(e) {;}}	
	