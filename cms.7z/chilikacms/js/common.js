$(document).ready(function() {
	$(".correct, .error").click(function() {
		$(this).hide(500);
	});
});
function fillURL(txtvalue,txtfld) {
	var nstr = "";
	for(var i=0;i<txtvalue.length;i++) {
		var iChars = "!@#$%^&*()+=[]\\\';,/{}|\":<> ?";
		if (iChars.indexOf(txtvalue.charAt(i)) != -1) {
			nstr += '-';
		}
		else if(txtvalue[i]==" ") {	nstr += '-'; }
		else if(txtvalue[i]=="?") {	nstr += ''; }
		else {
			nstr += txtvalue[i];
		}
	}
	while (nstr.indexOf("--")!=-1){
		nstr=nstr.replace("--","-");
	}
	document.getElementById(txtfld).value = nstr.toLowerCase();
}
function ShowUpload(){
	$('#file').show();
	$('#desc').hide();
	$('#link').hide();
}
function ShowDesc(){
	$('#desc').show();
	$('#file').hide();
	$('#link').hide();
}
function Showlink(){
	$('#link').show();
	$('#desc').hide();
	$('#file').hide();
} 
function chkboxNE(frm){ 
	if(!(frm.checked)){                   
		var id = frm.value;
		$.get("Ajax.php?q=uncheckedNE&id="+id,
		function(result) {
		//alert(result);
		$("#newBlink"+id).html(result);
		});
	
	}
	else{   
	var id = frm.value;
		$.get("Ajax.php?q=checkedNE&id="+id,
		function(result) {
		//alert(result);
		$("#newBlink"+id).html(result);
		});
	
	}
}
function chkboxVC(frm){ 
	if(!(frm.checked)){                   
		var id = frm.value;
		$.get("Ajax.php?q=uncheckedVC&id="+id,
		function(result) {
		//alert(result);
		$("#newBlink"+id).html(result);
		});
	
	}
	else{   
	var id = frm.value;
		$.get("Ajax.php?q=checkedVC&id="+id,
		function(result) {
		//alert(result);
		$("#newBlink"+id).html(result);
		});
	
	}
}
function chkboxPB(frm){ 
	if(!(frm.checked)){                   
		var id = frm.value;
		$.get("Ajax.php?q=uncheckedPB&id="+id,
		function(result) {
		//alert(result);
		$("#newBlink"+id).html(result);
		});
	
	}
	else{   
	var id = frm.value;
		$.get("Ajax.php?q=checkedPB&id="+id,
		function(result) {
		//alert(result);
		$("#newBlink"+id).html(result);
		});
	
	}
}
function chkboxAD(frm){ 
	if(!(frm.checked)){                   
		var id = frm.value;
		$.get("Ajax.php?q=uncheckedAD&id="+id,
		function(result) {
		//alert(result);
		$("#newBlink"+id).html(result);
		});
	
	}
	else{   
	var id = frm.value;
		$.get("Ajax.php?q=checkedAD&id="+id,
		function(result) {
		//alert(result);
		$("#newBlink"+id).html(result);
		});
	
	}
}


function chkboxAW(frm){ 
	if(!(frm.checked)){                   
		var id = frm.value;
		$.get("Ajax.php?q=uncheckedAW&id="+id,
		function(result) {
		//alert(result);
		$("#newBlink"+id).html(result);
		});
	
	}
	else{   
	var id = frm.value;
		$.get("Ajax.php?q=checkedAW&id="+id,
		function(result) {
		//alert(result);
		$("#newBlink"+id).html(result);
		});
	
	}
}

function chkboxTN(frm){ 
	if(!(frm.checked)){                   
		var id = frm.value;
		$.get("Ajax.php?q=uncheckedTN&id="+id,
		function(result) {
		alert("Status updated");
		$("#newBlink"+id).html(result);
		});
	
	}
	else{   
	var id = frm.value;
		$.get("Ajax.php?q=checkedTN&id="+id,
		function(result) {
		alert("Status updated");
		$("#newBlink"+id).html(result);
		});
	
	}
}