<?php
session_start();
require_once("../includes/settings.php");
require_once("../includes/database.php");
require_once("../includes/classes/db.cls.php");
require_once("../includes/classes/sitedata.cls.php");
require_once("includes/functions/common.php");
require_once("../includes/classes/HomeGalleries.cls.php");

loginValidate();
$db = new SiteData();
$homeObj = new HomeGalleries();

$act = isset($_REQUEST['act'])?$_REQUEST['act']:"";
$ext = array("html", "htm", "php");
define("ROOT_PATH","./");
$location = "home-gallery.php";
switch($act) {
	case "addphoto": {
		$homeObj->addPhoto($_REQUEST);
		$location = $_SERVER['HTTP_REFERER'];
	}break;
	case "editphoto": {
		$homeObj->editPhoto($_REQUEST);
		$location = $_SERVER['HTTP_REFERER'];
	}break;
	case "addcategory": {
		$homeObj->addCategory($_REQUEST);
		$location = $_SERVER['HTTP_REFERER'];
	}break;
		
	case "editcategory": {
		$homeObj->updateCategory($_REQUEST);
		$location = $_SERVER['HTTP_REFERER'];
	}break;
	
	case "del": {
		$id = (int)$_REQUEST['id'];
		$homeObj->deleteCategory($id);
		$location = $_SERVER['HTTP_REFERER'];
	}break;
	case "disable":{		
		$respond = $homeObj->disableStatus($_REQUEST['id']);
		header("location:".$location);
	}break;
	case "enable":{		
		$respond = $homeObj->enableStatus($_REQUEST['id']);
		header("location:".$location);
	}break;
	case "delphoto": {
		$id = (int)$_REQUEST['id'];
		$homeObj->deletePhoto($id);
		$location = $_SERVER['HTTP_REFERER'];
	}break;
	case "disablephoto":{		
		$respond = $homeObj->disableStatusPhoto($_REQUEST['id']);
		$cid = ($_REQUEST['cid']);
		$location = $_SERVER['HTTP_REFERER'];
	}break;
	case "enablephoto":{		
		$respond = $homeObj->enableStatusPhoto($_REQUEST['id']);
		$cid = ($_REQUEST['cid']);
		$location = $_SERVER['HTTP_REFERER'];
	}break;
	case "disableCatphoto":{		
		$respond = $homeObj->disableCatPhoto($_REQUEST['id']);
		$cid = ($_REQUEST['cid']);
		$location = $_SERVER['HTTP_REFERER'];
	}break;
	case "enableCatphoto":{		
		$respond = $homeObj->enableCatPhoto($_REQUEST['id'],$_REQUEST['cid']);
		$cid = ($_REQUEST['cid']);
		$location = $_SERVER['HTTP_REFERER'];
	}break;
	case "sort_photocatagory":{		
		$respond = $homeObj->sortPhotocatagory($_REQUEST);
		$location = $_SERVER['HTTP_REFERER'];
	}break;
	case "sort_photolist":{		
		$respond = $homeObj->sortPhotolist($_REQUEST);
		$location = $_SERVER['HTTP_REFERER'];
	}break;
	default : break;
}
redirect ($location);
?>