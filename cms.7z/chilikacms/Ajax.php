<?php
session_start();
require_once("../includes/settings.php");
require_once("../includes/database.php");
require_once("../includes/classes/db.cls.php");
require_once("../includes/classes/sitedata.cls.php");
require_once("includes/functions/common.php");

loginValidate();
$db = new SiteData();

$act = isset($_REQUEST['q'])?$_REQUEST['q']:"";
switch($act) {
	
	case "checkedVC": {
		$id = isset($_GET['id'])?$_GET['id']:0;
		$sql = "UPDATE  ".VISIT_CHILIKA." SET new =1 where id='$id'";
		$res = $db->update($sql);
		echo '<font color="#009966">ON</font>';
	}break;
	case "uncheckedVC": {
		$id = isset($_GET['id'])?$_GET['id']:0;
		$sql = "UPDATE  ".VISIT_CHILIKA." SET new =0 where id='$id'";
		$res = $db->update($sql);
		echo '<font color="#990000">OFF</font>';
		
	}break;
	case "checkedPB": {
		$id = isset($_GET['id'])?$_GET['id']:0;
		$sql = "UPDATE  ".PUBLICATION." SET new =1 where id='$id'";
		$res = $db->update($sql);
		echo '<font color="#009966">ON</font>';
	}break;
	case "uncheckedPB": {
		$id = isset($_GET['id'])?$_GET['id']:0;
		$sql = "UPDATE  ".PUBLICATION." SET new =0 where id='$id'";
		$res = $db->update($sql);
		echo '<font color="#990000">OFF</font>';
		
	}break;
	case "checkedAD": {
		$id = isset($_GET['id'])?$_GET['id']:0;
		$sql = "UPDATE  ".ADVERTISEMENT." SET new =1 where id='$id'";
		$res = $db->update($sql);
		echo '<font color="#009966">ON</font>';
	}break;
	case "uncheckedAD": {
		$id = isset($_GET['id'])?$_GET['id']:0;
		$sql = "UPDATE  ".ADVERTISEMENT." SET new =0 where id='$id'";
		$res = $db->update($sql);
		echo '<font color="#990000">OFF</font>';
		
	}break;
	
	case "uncheckedNE": {
		$id = isset($_GET['id'])?$_GET['id']:0;
		$sql = "UPDATE  ".NEWS_EVENTS." SET new =0 where id='$id'";
		$res = $db->update($sql);
		echo '<font color="#990000">OFF</font>';
		
	}break;
	case "checkedNE": {
		$id = isset($_GET['id'])?$_GET['id']:0;
		$sql = "UPDATE  ".NEWS_EVENTS." SET new =1 where id='$id'";
		$res = $db->update($sql);
		echo '<font color="#009966">ON</font>';
	}break;
	
	case "uncheckedAW": {
		$id = isset($_GET['id'])?$_GET['id']:0;
		$sql = "UPDATE  ".AWARDS." SET new =0 where id='$id'";
		$res = $db->update($sql);
		echo '<font color="#990000">OFF</font>';
		
	}break;
	case "checkedAW": {
		$id = isset($_GET['id'])?$_GET['id']:0;
		$sql = "UPDATE  ".AWARDS." SET new =1 where id='$id'";
		$res = $db->update($sql);
		echo '<font color="#009966">ON</font>';
	}break;
	case "uncheckedTN": {
		$id = isset($_GET['id'])?$_GET['id']:0;
		$sql = "UPDATE  ".TENDERS." SET new =0 where id='$id'";
		$res = $db->update($sql);
		echo '<font color="#990000">OFF</font>';
		
	}break;
	case "checkedTN": {
		$id = isset($_GET['id'])?$_GET['id']:0;
		$sql = "UPDATE  ".TENDERS." SET new =1 where id='$id'";
		$res = $db->update($sql);
		echo '<font color="#009966">ON</font>';
	}break;
	
}
?>