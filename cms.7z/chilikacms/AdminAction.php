<?php
session_start();
require_once("../includes/settings.php");
require_once("../includes/database.php");
require_once("../includes/classes/db.cls.php");
require_once("../includes/classes/sitedata.cls.php");
require_once("includes/functions/common.php");
require_once("../includes/classes/Admin.cls.php");
$db = new SiteData();
$adminObj = new Admin();
loginValidate();
$action = $_REQUEST['act'];
$location = "admin-manager.php";

$adminObj = new admin();
switch($action){		
	case "changeadminprofile":{		
		$respond = $adminObj->editAdmin($_REQUEST);
		$location = "my-account.php";
		header("location:".$location);
	}break;
	case "changeadminpass":{		
		$respond = $adminObj->changeAdminPass($_REQUEST);
		$location = "my-account.php";
	}break;
	case "changeadminLspass":{		
		$respond = $adminObj->changeAdminPass($_REQUEST);
		$location = "admin-manager.php";
	}break;
	case "addadmin":{		
		$respond = $adminObj->addAdmin($_REQUEST);
	}break;
	case "editadmin":{		
		$respond = $adminObj->updateAdmin($_REQUEST);
		$location .= "?q=edit&id=".$_REQUEST['admin_id'];
	}break;	
	case "deleteadmin":{		
		$respond = $adminObj->deleteAdmin($_REQUEST['id']);
		header("location:".$location);
	}break;		
	case "disable":{		
		$respond = $adminObj->disableStatus($_REQUEST['id']);
		header("location:".$location);
	}break;
	case "enable":{		
		$respond = $adminObj->enableStatus($_REQUEST['id']);
		header("location:".$location);
	}break;
	
	default: 
		header("location:".$location);
	break; 
}
redirect ($location);
?>
