<?php $required = "<font color='#FF0000' size='1'>*</font>";
$cid = $_REQUEST['cid'];
$id = $_REQUEST['id'];
$res = $homeObj->getPhotoById($id); 
$photo_id = $res['oDATA'][0]['photo_id'];
$photo_caption = outText($res['oDATA'][0]['photo_caption']);
?>
<div class="content_header">
  <div class="heading fleft">
    Update Photo
  </div>
  <div class="heading fright"> <a href="<?=$_curpage?>?q=photogallery&id=<?=$cid?>">&laquo; Back</a></div>
<div class="clear"></div>
</div>

<div class="bodycontent">
  <form name="frm" action="HomeAction.php" method="post" onsubmit="return photo_editvalid(this)" enctype="multipart/form-data">
    <input type="hidden" name="act" value="editphoto" />
	 <input type="hidden" name="photo_id" value="<?=$photo_id?>" />
    <div id="validation_div" class="validation_error" align="center"></div>
      <table width="100%" border="0" cellspacing="0" cellpadding="3" align="center">
        
        <tr>
          <td align="left" class="label">Title <?=$required?></td>
          <td align="center" class="label">:</td>
          <td><input type="text" name="photo_caption" size="80" value="<?=$photo_caption?>" /></td>
        </tr>
		 <tr>
          <td align="left" class="label">Upload Photo <?=$required?></td>
          <td align="center">:</td>
          <td>
			<input type="file" name="photo_file" onchange="javascript:return validNewsFile(this.value)" value=""/>		 </td>
        </tr>
         
        <tr>
          <td colspan="2">&nbsp;</td>
          <td align="left"><input type="submit" name="submit" value="Update Photo" class="button" />
	  	  <div style="color:#990000; font-style:italic; padding:5px;">Only Image with 1mb size allowed.</div>
		  </td>
        </tr>
      </table>
  </form>
</div>
