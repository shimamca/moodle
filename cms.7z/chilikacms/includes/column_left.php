<?php $admin_type = $_SESSION[SES]['admin']['admin_type'];?>
<div class="submenu" id="sub1">
	
	<div><a href="photo-gallery.php">Photo Gallery</a></div>
	
	<div><a href="banner.php">Banner Images</a></div>
	<div><a href="news-events.php">Article & Events</a></div>
	
	
	<div><a href="home-gallery.php">Home Photo Gallery</a></div>
	
	<div style="margin-top:6px;"><a href="welogs.php" target="_blank">Website Logs</a></div>
</div>
<script type="text/javascript">
var file, n;
file = window.location.pathname;
n = file.lastIndexOf('/');
if (n >= 0) {
    file = file.substring(n + 1);
}
var flag=0;
$('.submenu').children('div').each(function () {
    if($(this).children('a').attr("href")==file) {		
		$(this).addClass("active");
		flag=1;
	}
});
if(file=="") {
	$('.submenu div:first-child(1)').addClass("active");
}
</script>