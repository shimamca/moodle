<?php $required = "<font color='#FF0000' size='1'>*</font>";?>

<div class="content_header">
  <div class="heading fleft">Add New </div>
  <div class="heading fright"><a href="<?=$_curpage?>">&laquo; Back</a></div>
</div>
<div class="bodycontent">
	<div id="validation_div" class="validation_error"></div>

  <form action="BannerAction.php" method="post" enctype="multipart/form-data" name="addphotofrm" onsubmit="return add_photo_valid(this);">
<input type="hidden" name="act" value="add" />
<table  border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td>Enter Caption <?=$required?></td>
    <td><textarea name="photo_caption" rows="4" cols="45"></textarea></td>
  </tr>
  <tr>
    <td>Select Image <?=$required?></td>
    <td><input type="file" name="photo_file"/>
	<div><i style="color:#CC0000;">Image Dimensions should be 1000 &times; 330 px</i></div>
	</td>
  </tr> 
   
   <tr>    
    <td colspan="2" align="center" height="50" valign="bottom">
	<input name="submit" type="submit" value="Add Photo" class="button"/> &nbsp; &nbsp;
	<input name="reset" type="reset" value="Reset" class="button" />
	</td>
  </tr>
</table>
</form>
</div>