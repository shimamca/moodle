<div style="height:95px; background: url(images/top-bg.jpg) repeat-x;">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td align="right" width="140" align="bottom">
      <div style="margin-top:6px;"><img src="images/chilika_logo.png" border="0" align="bottom"/></div>
      </td>
      <td align="center"><div align="center" style="font-weight: 500; color:#FFFFFF;text-align:center;">
          <div style="font-size:1.9em;line-height:2.0em">
            <?=PAGE_TITLE?>
          </div>
          <div style="font-size:1.5em; color:#FFFF00;">Content Management System</div>
        </div></td>
      <td width="180" align="center"><?php if(isLoggedin()) { ?>
        <div class="headerlinkbox">
          <div class="headerlinks">Welcome</div>
          <div class="headerlinks">
            <?=$_SESSION[SES]['admin']['admin_name']?>
          </div>
          <div style="padding-top:8px;">
            <input type="button" class="signout" value="Sign out" onclick="document.location.href='logout.php'"/>
          </div>
        </div>
        <?php } else {echo '&nbsp';}?>
      </td>
    </tr>
  </table>
</div>
<?php getMessage();?>
