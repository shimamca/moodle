<script language="javascript">
function deletePhoto(u_id){
	if(confirm("Are you sure to delete this?")){
		document.location.href="BannerAction.php?act=del&id="+u_id;
	}
}
</script>
 <?php
$total_page = $bannerObj->getTotalPages(); 
$page = isset($_GET['page'])?(int)$_GET['page']:0;
$orderby = isset($_SESSION[SES]['banner']['orderby'])?$_SESSION[SES]['banner']['orderby']:"photo_id";
$order = isset($_SESSION[SES]['banner']['order'])?$_SESSION[SES]['banner']['order']:"desc";
$res = $bannerObj->getAllBanners($page*PAGE_LIMIT,$orderby, $order); 
$total = $res['NO_OF_ITEMS'];
?>
<div class="content_header">
  <div class="heading fleft">Banners</div>
  <div class="heading fright"><a href="<?=$_curpage?>?q=add">Add New</a></div>
  <div class="fright"> <?php if($total_page>1){?><select name="page" onchange="document.location.href='<?=$_curpage?>?page='+this.value" class="sel1"><?php
		for($i=0;$i<ceil($total_page/PAGE_LIMIT);$i++) {			
			if(isset($_GET['page']) && $_GET['page']!="" && $_GET['page']==$i) {
			echo '<option value="'.$i.'" selected="selected">Page '.($i+1).'</option>';}
			else {echo '<option value="'.$i.'">Page '.($i+1).'</option>';}
		} ?></select> &nbsp;&nbsp;|&nbsp;<?php }?></div>
  <div class="clear"></div>
</div>
<div class="bodycontent">
<?php if($total>0) {?>
<form action="BannerAction.php" method="post" >
<input type="hidden" name="act" value="sort_events" />
<table width="99%" border="1" bordercolor="#CCCCCC" cellspacing="0" cellpadding="3" align="center" class="datagrid" id="bannertable">	<tr>
		<th width="30">SL.No</th>
		<th>Caption</th>
		<th width="200">Photo</th>
		<th width="100">Date</th>
		<th colspan="4" width="130">Actions</th>
	</tr>
	<?php			
for($i=0;$i<$total;$i++) { 
	$photo_id = $res['oDATA'][$i]['photo_id'];
	$photo_file = outText($res['oDATA'][$i]['photo_file']);
	$photo_caption = outText($res['oDATA'][$i]['photo_caption']);
	$photo_date = outText($res['oDATA'][$i]['photo_date']);
	$sort_order = outText($res['oDATA'][$i]['sort_order']);
	$status = outText($res['oDATA'][$i]['status']);
	if($photo_file!="") {
		$image = "<img src='../photo/".$photo_file."' height='100' width='200' border='0' />";
	}
	else {$image = "";}
?>		
	<tr>
		<td align="center" width="5%"><?=($i+1)?></td>
		<td align="center" ><?=($photo_caption)?></td>
		<td align="center"><?=$image?></td>
		<td align="center" width="90"><?=$photo_date?></td>
		<td width="31" height="25" align="center"><?php if($status=="1") {  ?>
        <a href="BannerAction.php?act=disable&id=<?=$photo_id?>"><img src="images/enable.png" border="0" alt="Click to Disable" title="Disable"/></a>
        <?php
		} elseif ($status=="0") { ?>
        <a href="BannerAction.php?act=enable&id=<?=$photo_id?>"><img src="images/disable.png" border="0" alt="Enable" title="Click to Enable"/></a>
        <?php
		} ?>
      </td>
		<td width="50" height="25" align="center"><a href="<?=$_curpage?>?q=edit&id=<?=md5($photo_id)?>"><img border="0" src="images/edit.png" align="Edit" title="Edit" /></a></td>
		<td width="53" height="25" align="center"><a href="javascript:void(0)" onClick="deletePhoto(<?=$photo_id?>)"><img border="0" src="images/delete.png" align="Delete" title="Delete" /></a></td>
		<td width="25" align="center"><input type="text" class="minitbox" value="<?=$sort_order?>" name="sortorder[j<?=$photo_id?>]" size="3"/></td>
	</tr>
<?php } ?>          
</table>
<div align="right"><input type="submit" value="Update Sort Order" class="button"/></div>
</form>
  <?php } ?>
</div>
