<div id="footer">
<div class="fleft">&nbsp; &nbsp;<?=PAGE_TITLE?></div>
<div class="fright">&copy <?=PAGE_TITLE?>, All Rights Reserved&nbsp; &nbsp;</div>
<div class="clear"></div>
</div>